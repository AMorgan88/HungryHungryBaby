using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BottleCode : MonoBehaviour
{
    //create a transform
    private Transform BabyBottle = null;
    public float rotSpeed = 45f;
    public Transform Baby = null;

    void Awake()
    {
        //get the transform of the object and save it to BabyBottle
        BabyBottle = GetComponent<Transform>();
        
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //rotate the baby bottle using Rotation Speed * Time
        BabyBottle.Rotate(0, rotSpeed * Time.deltaTime, rotSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        //make a list of objects with the tag "Bottle"
        GameObject[] Collectable = GameObject.FindGameObjectsWithTag("Bottle");

        //if the tag does not equal "PlayerOne" return and do nothing
        if (!other.CompareTag("PlayerOne")) return;

        Destroy(gameObject);

        
    }
}
