using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Entry
{
    public string startTime;
    public float amountTime;
    public float amountFed;
}

public class UICode : MonoBehaviour
{
    public GameObject FeedButton;
    public GameObject UserInput;
    public GameObject SaveButton;
    public GameObject ExitButton;
    public GameObject MyVisClock;
    public GameObject StopButton;
    public GameObject MyMessage;
    public GameObject Instruction;

    public GameObject MainCamera;
    public GameObject UICamera;

    public InputField InputField;

    public Text StopWatch;
    public Text Message;

    public string str;

    public string begin;
    public float time;
    public float amount;
    public bool gameActive = false;

    const char DELIM = ',';

    public string myMin;
    public string mySec;

    public List<Entry> Entries = new List<Entry>() { };

    void Awake()
    {
        FeedButton = GameObject.FindGameObjectWithTag("FeedButton");
        StopButton = GameObject.FindGameObjectWithTag("StopFeed");
        UserInput = GameObject.FindGameObjectWithTag("UserInputBox");
        SaveButton = GameObject.FindGameObjectWithTag("SaveFeedButton");
        ExitButton = GameObject.FindGameObjectWithTag("ExitButton");
        StopWatch = GameObject.FindGameObjectWithTag("StopWatch").GetComponent<Text>();
        MyVisClock = GameObject.FindGameObjectWithTag("StopWatch");
        MyMessage = GameObject.FindGameObjectWithTag("ErrorMessage");
        Message = GameObject.FindGameObjectWithTag("ErrorMessage").GetComponent<Text>();
        Instruction = GameObject.FindGameObjectWithTag("Instruction");
        MainCamera = GameObject.FindGameObjectWithTag("PlayerOneCamera");
        UICamera = GameObject.FindGameObjectWithTag("UICamera");

        UserInput.SetActive(false);
        SaveButton.SetActive(false);
        MyVisClock.SetActive(false);
        StopButton.SetActive(false);
        MyMessage.SetActive(false);
        Instruction.SetActive(false);
    }

    public void FeedButtonClicked()
    {
        gameActive = true;
        MyVisClock.SetActive(true);
        FeedButton.SetActive(false);
        StopButton.SetActive(true);
        begin = System.DateTime.Now.ToString("yyyyMMdd_hhmmss");
    }

    public void StopFeedButtonClicked()
    {
        gameActive = false;
        StopButton.SetActive(false);
        Instruction.SetActive(true);
        UserInput.SetActive(true);
        SaveButton.SetActive(true);
        InputField.text = "";
        mySec = mySec.Substring(0, 2);
        myMin = myMin.Substring(0, 2);
        str = $"{myMin}.{mySec}";
        time = float.Parse(str);
    }

    public void SaveButtonClicked()
    {
        try
        {
            amount = float.Parse(InputField.text);

            if(amount != 0)
            {
                MyMessage.SetActive(false);
                MyVisClock.SetActive(false);
                SaveButton.SetActive(false);
                UserInput.SetActive(false);
                Instruction.SetActive(false);
                FeedButton.SetActive(true);

                Entries.Add(new Entry() { startTime = begin, amountTime = time, amountFed = amount });

                myMin = "00";
                mySec = "00";
                time = 0;
                StopWatch.text = $"{myMin}:{mySec}";
                InputField.text = "";
            }
            else
            {
                Message.text = "Cannot be Zero";
                MyMessage.SetActive(true);
            }
        }
        catch
        {
            Message.text = "Must be a Number";
            MyMessage.SetActive(true);
        }
    }

    public void ExitButtonClicked()
    {
        begin = "";
        myMin = "00";
        mySec = "00";
        time = 0;
        amount = 0;

        using (StreamWriter writer = new StreamWriter($@"C:\MyUnityProjects\HungryHungryBaby\MySavedData", true))
        {
            foreach (Entry newEntry in Entries)
            {
                writer.WriteLine($"{newEntry.startTime}{DELIM}{newEntry.amountTime}{DELIM}{newEntry.amountFed}");
            }
        }

        FeedButton.SetActive(true);
        UserInput.SetActive(false);
        SaveButton.SetActive(false);
        MyVisClock.SetActive(false);
        StopButton.SetActive(false);
        MyMessage.SetActive(false);
        Instruction.SetActive(false);

        ActivateMainCamera();
    }

    

    public void ActivateMainCamera()
    {
        UICamera.SetActive(false);
        MainCamera.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if (gameActive == true)
        {
            time += Time.deltaTime;
            mySec = (time % 60).ToString("00");
            myMin = Mathf.Floor((time % 3600)/60).ToString("00");

            StopWatch.text = $"{myMin}:{mySec}";
        }
    }
}

//V 2.0
//change StreamWriter to use a path instead of hard code
//Revert to using only the UI and polish UI to make it UserFriendly and simple.
//Load saved data using StreamReader and impliment graphical data : app will have different tabs to view graphs
//build a sleep tracking component