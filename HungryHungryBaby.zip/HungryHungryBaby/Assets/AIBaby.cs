using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AIBaby : MonoBehaviour
{
    private NavMeshAgent ThisAgent = null;
    public Transform Player = null;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    void Awake()
    {
        ThisAgent = GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        ThisAgent.SetDestination(Player.position);

        GameObject[] Collectable = GameObject.FindGameObjectsWithTag("Bottle");

        if (Collectable.Length <= 0)
        {
            Destroy(gameObject);
        }
    }
}
