using UnityEngine;

public class PlayerCode : MonoBehaviour
{
    private Transform PlayerOne = null;
    public float playerSpeed = 3f;
    public float rotSpeed = 150f;

    public GameObject MainCamera;
    public GameObject UICamera;

    void Awake()
    {
        PlayerOne = GetComponent < Transform>();
        MainCamera = GameObject.FindGameObjectWithTag("PlayerOneCamera");
        UICamera = GameObject.FindGameObjectWithTag("UICamera");

        UICamera.SetActive(false);
    }

    // Start is called before the first frame update
    void Start()
    {
        //PlayerOne = GetComponent<Transform>();
        //MainCamera = GameObject.FindGameObjectWithTag("PlayerOneCamera");
        //UICamera = GameObject.FindGameObjectWithTag("UICamera");

        //UICamera.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(MainCamera.gameObject.activeSelf == true)
        {
            float horz = Input.GetAxis("Horizontal");
            float vert = Input.GetAxis("Vertical");

            PlayerOne.Rotate(0, rotSpeed * Time.deltaTime * horz, 0);
            PlayerOne.position += PlayerOne.forward * playerSpeed * Time.deltaTime * vert;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        GameObject[] Collectable = GameObject.FindGameObjectsWithTag("Bottle");

        if (!other.CompareTag("Exit"))
        {
            return;
        }
        else if(other.CompareTag("Exit") && Collectable.Length <= 0)
        {
            UnityEditor.EditorApplication.isPlaying = false;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        GameObject[] Collectable = GameObject.FindGameObjectsWithTag("Bottle");

        if (!other.CompareTag("HungryHungryBaby"))
        {
            return;
        }
        else if (other.CompareTag("HungryHungryBaby") && Collectable.Length <= 0)
        {
            ActivateUICamera();
        }
    }

    public void ActivateUICamera()
    {
        MainCamera.SetActive(false);
        UICamera.SetActive(true);
    }
}
